export declare function unrar(from: string, to: string): Promise<string>;
//# sourceMappingURL=index.d.ts.map